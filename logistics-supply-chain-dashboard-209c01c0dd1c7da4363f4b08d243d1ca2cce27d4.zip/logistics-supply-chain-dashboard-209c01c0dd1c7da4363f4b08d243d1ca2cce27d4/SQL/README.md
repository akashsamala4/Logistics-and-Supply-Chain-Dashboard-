## SQL Scripts

This folder contains SQL scripts used in the Logistics & Supply Chain Dashboard project.

### Files:
- database_schema.sql – Database and table creation
- data_inserts.sql – Sample data insertion
- analysis_queries.sql – Business analysis and KPI queries
