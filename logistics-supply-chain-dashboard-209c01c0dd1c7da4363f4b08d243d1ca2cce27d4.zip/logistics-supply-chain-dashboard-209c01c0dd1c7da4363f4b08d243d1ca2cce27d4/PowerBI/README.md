Logistics_Dashboard.pbix – Interactive dashboard built using data from the MySQL logistics database

**Dashboard Highlights:**

KPIs: Total Orders, Total Revenue, On-Time Delivery %

Warehouse-wise revenue analysis

Shipment status (On-Time vs Late)

Date, Warehouse, Order Status, and Priority slicers

Geographic visualization of orders by state
